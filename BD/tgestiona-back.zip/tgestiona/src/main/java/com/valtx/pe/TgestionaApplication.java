package com.valtx.pe;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TgestionaApplication {

	public static void main(String[] args) {
		SpringApplication.run(TgestionaApplication.class, args);
	}

}
