package com.valtx.pe.tgestiona;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TgestionaApplicationTests {

	@Test
	void contextLoads() {
	}

}
